package com.te.service;

import java.util.List;

import com.te.Entity.DateNdTime;
import com.te.Entity.Doctor;
import com.te.Entity.Patient;

public interface DatendTimeService {
	public boolean insertDate(String date, String time,Doctor doctor,Patient patient);
public boolean insertpatientdate(String date, String time,Patient patient);
public List<DateNdTime> getAll();
public boolean getDate(int docId,String date,String time);
}
