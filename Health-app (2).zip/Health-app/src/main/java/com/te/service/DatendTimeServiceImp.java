package com.te.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.Entity.DateNdTime;
import com.te.Entity.Doctor;
import com.te.Entity.Patient;
import com.te.repository.DatenTimeImp;

@Service
public class DatendTimeServiceImp implements DatendTimeService {
@Autowired
	private DatenTimeImp repo;
	@Override
	public boolean insertDate(String date, String time, Doctor doctor,Patient patient) {
				return repo.insertDate(date, time, doctor,patient);
	}
	@Override
	public boolean insertpatientdate(String date, String time, Patient patient) {
		return repo.insertpatientdate(date, time, patient);
	}
	@Override
	public List<DateNdTime> getAll() {
		return null;
	}
	@Override
	public boolean getDate(int docId, String date, String time) {
		return repo.getDate(docId, date, time);
	}

}
